"""Seasonal mayor election (M6) — built on the M3 civic-poll engine.

An election is a civic poll whose options are candidate residents; each option
carries a ``{"type": "mayor", "slug": ...}`` effect. Voting (NPC rule-based +
player) and closing reuse ``civic_service`` verbatim. When the poll closes the
winner is installed as mayor:

  - ``meta_json['mayor'] = True`` on the winner (and cleared on everyone else),
    which the wage path reads for the town-wide bonus — no extra query;
  - ``current_mayor`` recorded in system_config for provenance;
  - the clerk posts the result, and the winner's bulletins carry a mayor badge
    implicitly via authorship.

Gated by ``settings.election_enabled``. Fail-open.
"""
from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.orm.attributes import flag_modified

from app.config import settings
from app.models.resident import Resident

logger = logging.getLogger(__name__)

ELECTION_TAG = "镇长选举"


async def open_election(db, *, candidate_slugs: list[str] | None = None, days: int | None = None):
    """Open a mayor election poll. Candidates default to ambitious, socially
    active NPCs (SBTI Ac1=H or So1=H). Returns the Poll or None."""
    if not settings.election_enabled:
        return None
    from app.services import civic_service

    residents = (await db.execute(
        select(Resident).where(Resident.resident_type == "npc")
    )).scalars().all()
    by_slug = {r.slug: r for r in residents}

    if candidate_slugs:
        candidates = [by_slug[s] for s in candidate_slugs if s in by_slug]
    else:
        candidates = [
            r for r in residents
            if _dim(r, "Ac1") == "H" or _dim(r, "So1") == "H"
        ]
        if len(candidates) < 2:  # fallback: highest-heat residents
            candidates = sorted(residents, key=lambda r: r.heat or 0, reverse=True)[:3]
    candidates = candidates[:4]
    if len(candidates) < 2:
        return None

    options = [
        {"label": c.name, "effect": {"type": "mayor", "slug": c.slug}}
        for c in candidates
    ]
    return await civic_service.propose(
        db, f"{ELECTION_TAG}:谁来当下一任镇长?", options, days=days,
    )


async def install_mayor(db, slug: str | None) -> bool:
    """Set ``slug`` as the sitting mayor (clearing any previous one) and record
    it in system_config. Returns True on success."""
    if not slug:
        return False
    residents = (await db.execute(
        select(Resident).where(Resident.resident_type == "npc")
    )).scalars().all()
    winner = None
    for r in residents:
        meta = dict(r.meta_json or {})
        was = bool(meta.get("mayor"))
        should = (r.slug == slug)
        if was != should:
            if should:
                meta["mayor"] = True
                winner = r
            else:
                meta.pop("mayor", None)
            r.meta_json = meta
            flag_modified(r, "meta_json")
        elif should:
            winner = r
    await db.commit()

    if winner is None:
        return False
    try:
        from app.services.config_service import ConfigService
        await ConfigService(db).set(
            "current_mayor", slug, group="civic", updated_by="election",
        )
    except Exception:
        logger.warning("recording current_mayor failed", exc_info=True)
    try:
        from app.services.feed_service import push
        await push(slug, "goal_achieved", {"goal": "当选小镇镇长"})
        from app.memory.service import MemoryService
        await MemoryService(db).add_memory(
            winner.id, "event",
            "我当选了小镇的镇长。这份信任沉甸甸的,得对得起投我票的每一个人。",
            0.9, "reflection",
        )
    except Exception:
        logger.warning("mayor install side-effects failed", exc_info=True)
    return True


async def current_mayor(db) -> str | None:
    from app.services.config_service import ConfigService
    try:
        return await ConfigService(db).get("current_mayor")
    except Exception:
        return None


def _dim(resident, code: str) -> str:
    return (resident.meta_json or {}).get("sbti", {}).get("dimensions", {}).get(code, "M")
